//
// Javascript manifest for main site
//
// require jquery_ujs
;
